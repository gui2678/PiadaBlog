class PostsController < ApplicationController
  before_action :authenticate_user!, only: %i[new create destroy my_posts]
  before_action :set_post, only: %i[show edit update]

  # GET /posts or /posts.json
  def index
    @posts = Post.all.order(created_at: :desc)
  end

  def edit
    @post = Post.find(params[:id])
    redirect_to posts_path, alert: "Not authorized." unless @post.user == current_user
  end

  def update
    @post = Post.find(params[:id])
    if @post.user != current_user
      redirect_to posts_path, alert: "Not authorized."
    elsif @post.update(post_params)
      redirect_to @post, notice: "Post was successfully updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def my_posts
    @posts = current_user.posts.order(created_at: :desc)
    render :index
  end

  # GET /posts/1 or /posts/1.json
  def show
    @post = Post.find(params[:id])
  end

  # GET /posts/new
  def new
    @post = Post.new
  end

  # POST /posts or /posts.json
  def create
    @post = Post.new(post_params)
    @post.user = current_user # using Devise so posts belong to users

    if @post.save
      redirect_to @post, notice: 'Post was successfully created.'
    else
      render :new, status: :unprocessable_entity
    end
  end

  # DELETE /posts/1 or /posts/1.json
  def destroy
    @post = current_user.posts.find(params[:id])
    @post.destroy
    redirect_to my_posts_path, notice: 'Post deleted'
  end

  private
    def set_post
      @post = Post.find(params[:id])
    end

    def post_params
      params.require(:post).permit(:title, :body)
    end
end
