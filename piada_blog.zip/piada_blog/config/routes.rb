Rails.application.routes.draw do
  root 'posts#index'

  devise_for :users

  resources :posts
  get 'my_posts', to: 'posts#my_posts'
  get 'all_posts', to: 'posts#index', as: 'all_posts'
end
